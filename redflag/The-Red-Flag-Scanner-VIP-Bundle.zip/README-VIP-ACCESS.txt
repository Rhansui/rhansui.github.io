========================================================================
         THE RED FLAG SCANNER™ · OFFICIAL VIP ACCESS & CHEAT SHEET
========================================================================

Thank you for your purchase! You now own lifetime access to The Red Flag Scanner™.

------------------------------------------------------------------------
1. INSTANT WEB APP (LIVE CLOUD ACCESS)
------------------------------------------------------------------------
You can use the live web app on any smartphone (iPhone / Android) or PC:
👉 https://rhansui.github.io/redflag/

PRO-TIP:
Open the link on Safari or Chrome, tap "Share" -> "Add to Home Screen".
It will sit right on your phone like a native app icon!


------------------------------------------------------------------------
2. OFFLINE STANDALONE APP (INCLUDED IN THIS ZIP)
------------------------------------------------------------------------
Double-click "The-Red-Flag-Scanner.html" in this folder.
It runs 100% locally in your browser, even without an internet connection or on airplane mode.


------------------------------------------------------------------------
3. EMERGENCY SAVAGE 1-CLICK EXIT TEXTS CHEAT SHEET
------------------------------------------------------------------------

[TIER 1: HIGH TOXICITY - SAVAGE & ICE-COLD]
1. ICE-COLD CORPORATE:
   "I've decided to unsubscribe from your free trial of emotional availability. Wishing you the best!"
2. THE PHANTOM CLOSURE:
   "You wanted mystery and space. Now you have both, permanently."
3. THE REVERSE GASLIGHT:
   "I don't argue with people who confuse drama with passion. Take care of yourself."

[TIER 2: MODERATE RISK - BOUNDARIES & ENERGY MIRROR]
1. THE ENERGY MIRROR:
   "I've matched your effort level. Notice how quiet it got?"
2. THE BOUNDARY STRIKE:
   "Mixed signals are a no for me. Let's leave things right here."
3. CALM DISENGAGEMENT:
   "I'm stepping back from connections that drain my peace. Wishing you well."

[TIER 3: HEALTHY SCORE - OPEN COMMUNICATION]
1. OPEN CHECK-IN:
   "Hey, I value what we're building. Wanted to check in on how you're feeling lately."
2. GENTLE REALIGNMENT:
   "Let's make sure we're on the same page about what we want moving forward."
3. AFFIRMATION:
   "Appreciate your consistency and respect. It really stands out."

========================================================================
Licensed to the original buyer. Unlimited scans & lifetime updates included.
========================================================================
